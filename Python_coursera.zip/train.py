#import lib
import argparse
import torch
import torchvision
from torch import nn, optim

from torch.utils import data
from torchvision.datasets import ImageFolder

from torchvision import transforms
import os

def training_data(args):
    # Define transformations, ImageFolder & DataLoader
    # Returns DataLoader objects for training and validation, and a class_to_idx dictionary
    trainning_directory = os.path.join(args.data_directory, "train")
    valid_directory = os.path.join(args.data_directory, "valid")

    # Validate paths before proceeding
    for dir_path in [args.data_directory, args.save_directory, trainning_directory, valid_directory]:
        if not os.path.exists(dir_path):
            print(f"Directory doesn't exist: {dir_path}")
            raise FileNotFoundError

    # Define transformations for training and validation data
    trainning_transforms = transforms.Compose([
        transforms.RandomRotation(30),
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.552, 0.5576, 0.5586], [0.255, 0.255, 0.255])
    ])

    valid_transf = transforms.Compose([
        transforms.Resize(255),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.411, 0.433, 0.431], [0.213, 0.226, 0.224])
    ])

    # Create datasets and dataloaders for training and validation
    trainning_data = ImageFolder(root=trainning_directory, transform=trainning_transforms)
    valid_data = ImageFolder(root=valid_directory, transform=valid_transf)

    trainning_data_loader = data.DataLoader(trainning_data,_size=64, shuffle=True)
    validdate_data_loader = data.DataLoader(valid_data,_size=64, shuffle=True)

    return trainning_data_loader, validdate_data_loader, trainning_data.class_to_idx

def training_mode(args, trainning_data_loader, validdate_data_loader, class_to_idx):
    # Trains model, saves model to directory, returns True if successful
    
    # Build model using pretrained VGG model    
    if args.model_arch == "vgg11":
        model = torchvision.models.vgg11(pretrained=True)
    elif args.model_arch == "vgg13":
        model = torchvision.models.vgg13(pretrained=True)
    elif args.model_arch == "vgg16":
        model = torchvision.models.vgg16(pretrained=True)
    elif args.model_arch == "vgg19":
        model = torchvision.models.vgg19(pretrained=True)

    # Freeze model parameters
    for param in model.parameters():
        param.requires_grad = False

    in_features_of_pretrained_model = model.classifier[0].in_features

    # Modify the classifier
    classifier = nn.Sequential(
        nn.Linear(in_features=in_features_of_pretrained_model, out_features=2048, bias=True),
        nn.ReLU(inplace=True),
        nn.Dropout(p=0.2),
        nn.Linear(in_features=2048, out_features=102, bias=True),
        nn.LogSoftmax(dim=1)
    )
    model.classifier = classifier

    # Train model
    criterion = nn.NLLLoss()
    optimizer = optim.Adam(model.classifier.parameters(), lr=args.learning_rate)

    device = 'cuda' if args.gpu and torch.cuda.is_available() else 'cpu'
    model.to(device)

    print(f"Using {device} to training model...")

    print_every = 20

    # Train the model for each epoch
    for epoch in range(args.epochs):
        step = 0
        running_train_loss = 0
        running_valid_loss = 0

        for images, labels in trainning_data_loader:
            step += 1

            model.train()
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(images)
            train_loss = criterion(outputs, labels)
            train_loss.backward()
            optimizer.step()
            running_train_loss += train_loss.item()

            if step % print_every == 0 or step == 1 or step == len(trainning_data_loader):
                percent_complete = (step * args.batch_size) * 100 / len(trainning_data_loader.dataset)
                print("Epoch: {}/{} Value % Completed: {:.2f}%".format(epoch+1, args.epochs, percent_complete))

        # Validation
        model.eval()
        with torch.no_grad():
            print("Valid....")
            running_accuracy = 0
            running_valid_loss = 0
            for images, labels in validdate_data_loader:
                images, labels = images.to(device), labels.to(device)
                outputs = model(images)
                valid_loss = criterion(outputs, labels)
                running_valid_loss += valid_loss.item()

                ps = torch.exp(outputs)
                top_p, top_class = ps.topk(1, dim=1)
                equals = top_class == labels.view(*top_class.shape)
                running_accuracy += torch.mean(equals.type(torch.FloatTensor)).item()

            average_train_loss = running_train_loss / len(trainning_data_loader)
            average_valid_loss = running_valid_loss / len(validdate_data_loader)
            accuracy = running_accuracy / len(validdate_data_loader)
            print("Training Faile: {:.2f}".format(average_train_loss))
            print("Valid Faile: {:.2f}".format(average_valid_loss))
            print("Accuracy rate: {:.2f}%".format(accuracy * 100))

    # Save model
    model.class_to_idx = class_to_idx
    checkpoint = {
        'classifier': model.classifier,
        'state_dict': model.state_dict(),
        'epochs': args.epochs,
        'optim_stat_dict': optimizer.state_dict(),
        'class_to_idx': model.class_to_idx,
        'vgg_type': args.model_arch
    }

    torch.save(checkpoint, os.path.join(args.save_directory, "checkpoint_resnet50.pth"))
    print("Model saved to {}".format(os.path.join(args.save_directory, "checkpoint_resnet50.pth")))
    return True

if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    # Required param arguments
    parser.add_argument(dest='data_directory', help="Directory containing the training images.")

    # Optional param arguments
    parser.add_argument('--save_directory', dest='save_directory', help="The directory where the trained model will be saved. Default is '../saved_models'.")
    parser.add_argument('--learning_rate', dest='learning_rate', help="The learning rate used during model training. Default is 0.003.", default=0.003, type=float)
    parser.add_argument('--epochs', dest='epochs', help="The number of epochs to train the model. Default is 3.", default=3, type=int)
    parser.add_argument('--gpu', dest='gpu', help="Include this argument to train the model on the GPU using CUDA.", action='store_true')
    parser.add_argument('--model_arch', dest='model_arch', help="The type of pre-trained model to be used. Options: 'vgg11', 'vgg13', 'vgg16', 'vgg19'. Default is 'vgg19'.")

    # Parse  results
    args = parser.parse_args()

    # Load and tran
    trainning_data_loader, validdate_data_loader, class_to_idx = training_data(args)
    #call Traning
    training_mode(args, trainning_data_loader, validdate_data_loader, class_to_idx)
